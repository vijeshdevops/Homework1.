## For this program, we'll use binary search to quickly find smallest x,y,z combinations that makes x^n + y^n close to z^n.

def binary_search(x, y, n, k):
    # Calculate x^n + y^n
    x_y = x**n + y**n
   
   # Initializing binary search, smallest z and smallest miss variables
    low = max(x, y) + 1
    high = k
    bst_z = low
    bst_miss = float('inf')
    # Perform binary search
    while low <= high:
        mid = (low + high) // 2
        m = mid**n

        # Calculate the difference from x^n + y^n to m
        if m < x_y:
            miss = x_y - m
            zn = mid
        else:
            miss = m - x_y
            zn = mid - 1

        # Update smallest miss and smallest z
        if miss < bst_miss:
            bst_miss = miss
            bst_z = zn

        # adjust low and high values
        if m < x_y:
            low = mid + 1
        else:
            high = mid - 1
    #return smallest miss and smallest z 
    return bst_miss, bst_z

def calc_miss(n, k):

    bst_miss = float('inf')
    bst_x = 0
    bst_y = 0
    bst_z = 0

    # while loop to iterate through x, y combinations 
    x = 10
    while x <= k:
        y = 10
        while y <= k:
            # call binary_search to find the smallest miss and smallest z for given x, y
            miss, z = binary_search(x, y, n, k)
            # calculate relative miss percentage
            rel_miss = (miss / (x**n + y**n)) * 100

            # check and update the smallest miss, x,y and z values
            if rel_miss < bst_miss:
                bst_miss = rel_miss
                bst_x, bst_y, bst_z = x, y, z

            # Print the possible combination of x, y, z along with actual miss and relative miss percentage
            if miss != float('inf'):
                print(f"\nx: {x}\ny: {y}\nz: {z}\nActual miss: {miss}")
                print(f"Relative miss percentage: {round(rel_miss,2)}%")
                

            y += 1
        x += 1

    return bst_x, bst_y, bst_z, bst_miss

def main():
    # requesting for n and k values from the user as an input
    n = int(input("Enter value for n such that 2 < n < 12 : "))
    k = int(input("Enter value for k such that k > 10 : "))

    #conditional check for n and k inputs
    if n > 11 or n < 3 or k < 10:
        print("Enter valid inputs")
        input()
        return
    else: 
    #function call for calc_miss() 
     bst_x, bst_y, bst_z, bst_miss = calc_miss(n, k)

    # Calculate smallest actual miss
     small_act_miss = abs(bst_x**n + bst_y**n - bst_z**n)

    # Print the final smallest x,y,z values
     print(f"\nsmallest x = {bst_x}\nsmallest y = {bst_y}\nsmallest z = {bst_z}")

    # print the final smallest actual miss and relative miss percentage
     print(f"smallest actual miss: {small_act_miss}")
     print(f"smallest relative miss percentage: {round(bst_miss, 2)}%")
     input()

if __name__ == "__main__":
    main()
