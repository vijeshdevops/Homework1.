## Prerequisites

Python3 must be installed on your system to run the code.

## Instructions to run the code

1. Clone the repository in your computer or download the program file hw1.py.

2. Open the code in any code editor to view and run the code.

3. Navigate to the directory where the program file is located in code editor terminal.

4. execute the code running following command:

   python3 hw1.py
